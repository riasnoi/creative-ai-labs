ЛР03, вариант 13. Архив исходников и первичных артефактов.
Папка engee содержит точные массивы из Julia, PNG, гистограммы и логи.
Проверка после распаковки: python3 tools/verify_results.py artifacts/engee
Требования: Python 3.11+ и NumPy из requirements.txt.
Полные отчёты Word/PDF и манифест комплекта находятся в репозитории lab_03.
